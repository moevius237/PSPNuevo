package UD3.networking.pairProgramming.ej1;

public class Eje1 {
    public static void main(String[] args) {


    }
}
