package UD3.networking.tcp;

/**
 * Capa de transporte --> UDP, TCP
 * TCP --> orientado a conexion
 * UDP --> no te asegura que los paquetes llegan
 */

public class NetworkingTest {
    public static void main(String[] args) {

    }
}
