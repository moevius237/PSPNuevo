package UD3.networking.repasoUDP;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class Escritor {
    private static final String filename ="file/informe_carrera.txt";

    public void write(String texto){
        try (BufferedWriter bw = Files.newBufferedWriter(Path.of(filename),StandardOpenOption.APPEND,StandardOpenOption.CREATE)){
            bw.write(texto);
            bw.newLine();

        }catch (IOException e){
            e.getCause();
        }
    }
}
