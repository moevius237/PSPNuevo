package UD3.networking.repasoUDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RacerSErver {
    public static void main(String[] args) {
        try (DatagramSocket datagramSocket = new DatagramSocket(5000)){
            ExecutorService executorService = Executors.newCachedThreadPool();
            Escritor escritor = new Escritor();
            while (true){
                byte [] biffer = new byte[50];
                DatagramPacket datagramPacket = new DatagramPacket(biffer, biffer.length);
                datagramSocket.receive(datagramPacket);
                executorService.execute(new RacerManager(datagramPacket,escritor));
            }
        } catch (SocketException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
