package UD3.networking.repasoUDP;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.StringJoiner;

public class RacerManager implements Runnable{
    private final DatagramPacket packet;

    private final Escritor escritor;
    public RacerManager(DatagramPacket packet, Escritor escritor) {
        this.packet = packet;
        this.escritor = escritor;
    }


    @Override
    public void run() {
            String mensaje = packet.toString();
            StringJoiner joiner = new StringJoiner(";");
            joiner.add(mensaje);
            joiner.add(LocalDateTime.now().toString());
            System.out.println("IMPRIME");
            escritor.write(joiner.toString());
    }
}
