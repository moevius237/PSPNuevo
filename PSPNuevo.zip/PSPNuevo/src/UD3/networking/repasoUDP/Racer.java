package UD3.networking.repasoUDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.StringJoiner;

/**
 * cada minut
 */
public class Racer {
    private static final int SERVER_PORT = 5000;
    public static void main(String[] args) {
        try (DatagramSocket datagramSocket = new DatagramSocket()){

            while (true) {
                String corredor = "Pablo";
                StringJoiner joiner = new StringJoiner(";");
                Random r = new Random();
                joiner.add(corredor);
                joiner.add(Integer.toString(r.nextInt(1, 100)));
                joiner.add(Integer.toString(r.nextInt(1, 100)));
                byte[] buffer = joiner.toString().getBytes(StandardCharsets.UTF_8);
                DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), SERVER_PORT);
                datagramSocket.send(dp);
                Thread.sleep(2000);
            }
        } catch (SocketException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
