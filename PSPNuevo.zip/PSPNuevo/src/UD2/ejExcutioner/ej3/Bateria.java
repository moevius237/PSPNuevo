package UD2.ejExcutioner.ej3;

import UD2.bateriaCompartida.BateriaProductor;

import java.util.Random;

public class Bateria {
}