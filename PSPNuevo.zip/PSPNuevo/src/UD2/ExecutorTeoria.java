package UD2;

public class ExecutorTeoria {
    /**
     * ExecutorService
     * -NewSingleThread --> 1
     * -NEwFixedThread(nTHread)
     * -NewCachedThreadPool
     *
     *      *execute(Runnable)->no devuelve nada
     *      *subnit(Runnable)->Future
     *      *submit(Callable<T>)->future<T>
     *       *invokeAll(List<Callable>) -> LIst<Future<T>>
     *
     *
     * newScheduledThreadPOol(nTHread)
     * -Schedule --> ejecuta una tarea con un delay
     * -scjeduleAtFixedRate --> ejecuan sin parar los turnos
     * -scheduleWithFixedDelay --> ejecutasin parar las tarea
     */

    /**
     * Lo que sale en el examen
     * Interferencia
     * Sincronizar -> wait(), notify(), notifyAll()
     * Executors
     */
}
