package UD2.ThreadColorPrubea;

public class Hilito1 {
    public static void main(String[] args) {

    }
}
