package UD2.parking;

public record Coche(int id) {
}
