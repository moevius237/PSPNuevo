package UD2.puente;

/*
Ejercicio puente
El siguiente programa simula un sistema que controla el paso de personas por un puente siempre en la misma dirección
para que se cumplan las restricciones que ahora veremos

Restricciones
No pueden pasar mas de 3 personas y no puede haber mas de 200 kg a la vez
los hilos seran las perosonas

el tiempo entre la llegada de dos personas al puente el tiempo entre la llegada de dos personas es aleatorio entre 1 y5 sec
y el timepo para atrevasar al puente es aleatrio entre 10 y 20 sec
las personas un peso aleatorio entre 40 y 120 kg
tendremos que crear una clase puente el objeto compartido
guarda el estado compartido por todos los hilos que seran el peso actual y las pesonas que hay ahora
Este objeto se pasara a todos los hilos de la clase persona con el contructor
puente tendra un metodo llamado autorizacion paso para pasar por el puente
tambien tendra otro metodo llamado termina paso que quita las personas del puente junto su peso
 */
public class PuenteMain {
    public static void main(String[] args) {
        PuenteCompartido puenteCompartido = new PuenteCompartido();
        PersonaEntra personaEntra = new PersonaEntra(puenteCompartido);
        PersonaSale personaSale = new PersonaSale(puenteCompartido);

        personaEntra.start();
        personaSale.start();

    }
}
