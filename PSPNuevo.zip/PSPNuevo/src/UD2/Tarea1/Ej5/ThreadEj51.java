package UD2.Tarea1.Ej5;

public class ThreadEj51 extends Thread {
    @Override
    public void run() {
        Thread.interrupted();
    }
}
