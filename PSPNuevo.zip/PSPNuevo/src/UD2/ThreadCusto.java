package UD2;

public class ThreadCusto implements Runnable{
    @Override
    public void run() {
        System.out.println("Hilo");
    }
}
