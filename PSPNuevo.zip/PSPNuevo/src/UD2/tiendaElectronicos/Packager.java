package UD2.tiendaElectronicos;

public class Packager extends Thread{
    @Override
    public void run() {
        super.run();
    }
}
