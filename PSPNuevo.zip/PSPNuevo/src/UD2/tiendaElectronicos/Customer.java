package UD2.tiendaElectronicos;

public class Customer extends Thread{
    @Override
    public void run() {
        super.run();
    }
}
