package UD2;
/*
Crear hilos
interferncia
sincronizacion -> deadlock
notify,wait,notifyAlL()

 */
public class Examen {
}
