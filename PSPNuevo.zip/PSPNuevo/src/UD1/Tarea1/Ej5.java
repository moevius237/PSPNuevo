package UD1.Tarea1;

public class Ej5 {
    public static void main(String[] args) {
    //This represents the error code that it gives, 0 is correct, 2 is that an IOException and 3 if an InterruptedException
    //The inheritIO method is used to indicate that the child procces should inherit de streams from the parent procces
    }
}
