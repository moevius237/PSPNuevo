package UD1;

/**
 * Dos formas para crear procesos
 * -ProccesBuilder
 * -Runtime
 *
 * -Procces:
 * -waitFor()-> esoera y devuelve codigo
 * -isAlive()-> proceso activo
 *
 * -getInputStream()-> Salida
 * -getOutputStream()->entrada
 * -getErrorStream()->Salida
 *
 * ProccesBuiolder
 * -redirectInput -> escribir desde el intelli
 * -redirectOutput ->redirijo la salida de proceso al intelli
 * -redirectError -> Mostrare el error en el intelli
 *
 * InheritIO();
 *
 * //Nombrado
 *
 * //Excepciones
 */
public class Repaso {
}
